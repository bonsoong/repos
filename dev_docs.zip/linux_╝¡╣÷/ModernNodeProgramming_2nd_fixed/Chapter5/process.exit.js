﻿// 이벤트를 연결합니다.
process.on('exit', function () {

});
