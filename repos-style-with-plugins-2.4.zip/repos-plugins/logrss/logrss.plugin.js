// This is an alternative to editing the xslt body if you already have javascript and jQuery running
// Instead of adding
// 			<a id="logrss" class="command translate" 
//				href="/repos-plugins/logrss/?base={/svn/index/@base}&amp;target={/svn/index/@path}"
//				style="background-image:url('/repos-plugins/logrss/feed.png')">rss</a>
// to #commandbar in repos.xsl add the following to head (works in log.xsl too):
// 	<script type="text/javascript" src="/repos-plugins/logrss/logrss.plugin.js"></script>

$(document).ready(function() {
	
	var pluginUrl = '/repos-plugins/logrss/';
	var rssUrl = '';
	
	var reposMeta = function(id) {
		return $('meta[name=repos-' + id + ']').attr('content');
	};
	
	if ($('body').is('.repository')) {
		var target = reposMeta('target');
		if (target == '//') {
			target = '/'; // fix for the inconsistency in svn index root
		}
		var base = reposMeta('base');
		rssUrl = pluginUrl + '?base=' + base + '&target=' + encodeURIComponent(target);
	} else if ($('body').is('.log')) {
		rssUrl = pluginUrl + location.search;
	} else {
		return;
	}
	
	var command = $('<a id="logrss"/>').attr('href', rssUrl)
	// command bar
	//command.text('rss').css('background-image', 'url(' + pluginUrl + 'feed-icon-16x16.png');
	//command.appendTo('#commandbar');
	// footer
	command.append($('<img/>').attr('src', pluginUrl + 'feed-icon-14x14.png').css({border: 0, verticalAlign: 'text-top'}));
	$('#footer').append('<span class="spacer">&nbsp;&nbsp;</span>').append(command);
	
	// make the RSS show up in page info
	var info = $('<link rel="alternate" type="application/rss+xml"/>').attr('title', 'Subversion log RSS').attr('href', rssUrl).appendTo('head');
	
});