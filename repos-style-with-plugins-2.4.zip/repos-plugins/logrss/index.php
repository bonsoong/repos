<?php

// first get log output and log's global variables
ob_start();
require('../../repos-web/open/log/index.php');
$xml = ob_get_contents();
ob_end_clean();
isset($url) or trigger_error('log script is expected to define an "url" variable');

// override headers set by log
header('Content-Type: text/xml');

// set feed style and parameters
$xsltsource = dirname(__FILE__).'/svnlog-xslt/svnlog.xslt';
// default parameters, can be overridden below
$parameters = array(
	// feed metadata
	'feedname' => "repos: $url",
	'copyright' => "",
	// this is used for "link" in feed metadata 
	'projecturl' => "$url",
	// Changed paths will be appended to this for links. If empty the change items will not be links.
	'repositoryBaseUrl' => isset($repo) ? $repo : rtrim($url,'/'),
	// This is optional to map email addresses to commit authors
	'usersDocument' => "users.xml"
);
// never display local path
if (strpos($url,'file://')===0) {
	$host = $_SERVER['HTTP_HOST'];
	$repoid = isset($_REQUEST['base']) ? ' '.$_REQUEST['base'] : '';
	$parameters['feedname'] = "$host$repoid";
	$parameters['projecturl'] = "http://$host/";
}
// disable links by default when log is based on file:// url
if (strpos($parameters['repositoryBaseUrl'],'file://')===0) {
	$parameters['repositoryBaseUrl'] = '';
}

// allow local customization, a file containing for example
// <?php $parameters['repositoryBaseUrl'] = 'http://example.com/svn'; ...
if (file_exists('local-settings.php')) {
	require('local-settings.php');
}

// transform to response
if (class_exists('XSLTProcessor')) {
	// use php5-xsl extension
	$xslDoc = new DOMDocument();
	$xslDoc->load($xsltsource);
	
	$xmlDoc = new DOMDocument();
	$xmlDoc->loadXml($xml);
	
	$proc = new XSLTProcessor();
	$proc->importStylesheet($xslDoc);
	foreach ($parameters as $k => $v) {
		$proc->setParameter('', $k, $v);
	}
	echo $proc->transformToXML($xmlDoc);
} else {
	// use command line xsltproc
	$tmp = tempnam(sys_get_temp_dir(), 'FOO');
	$tmpf = fopen($tmp, 'w');
	fwrite($tmpf, $xml);
	fclose($tmpf);
	// this, of course, assumes xsltproc is installed
	$xsltproc = 'xsltproc';
	foreach ($parameters as $k => $v) {
		$xsltproc .= ' --param '.escapeshellarg($k).' "'.escapeshellarg($v).'"';
	}
	$xsltproc .= ' "'.$xsltsource.'"';
	$xsltproc .= ' "'.$tmp.'"';
	passthru($xsltproc, $exitcode);
	if ($exitcode) trigger_error('Error code '.$exitcode.' executing: '.$xsltproc, E_USER_ERROR);
	unlink($tmp);
}

?>
